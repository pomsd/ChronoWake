package com.example

import android.app.Application
import android.app.NotificationManager
import android.content.Context
import com.example.receiver.AlarmReceiver

class ChronoWakeApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        AlarmReceiver.createNotificationChannel(notificationManager)
    }
}
