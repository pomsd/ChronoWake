package com.example.scheduler

import com.example.data.model.Alarm
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.max

object AlarmCalculationUtil {

    /**
     * Calculates the next trigger time in epoch millis for an alarm.
     * Takes recurring day schedule into account.
     */
    fun calculateNextTriggerMillis(alarm: Alarm, now: LocalDateTime = LocalDateTime.now()): Long {
        // If alarm has an active snooze, that takes priority
        if (alarm.snoozedUntilMillis > System.currentTimeMillis()) {
            return alarm.snoozedUntilMillis
        }

        val targetTime = LocalTime.of(alarm.hour, alarm.minute, 0)
        val today = now.toLocalDate()
        val currentDayOfWeek = now.dayOfWeek.value // 1 (Mon) .. 7 (Sun)

        if (alarm.recurringDays.isEmpty()) {
            // One-time alarm
            var candidateDateTime = LocalDateTime.of(today, targetTime)
            if (!candidateDateTime.isAfter(now)) {
                // Time has already passed today, ring tomorrow
                candidateDateTime = candidateDateTime.plusDays(1)
            }
            return candidateDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }

        // Recurring alarm: check the next 7 days starting today
        for (dayOffset in 0..7) {
            val candidateDate = today.plusDays(dayOffset.toLong())
            val candidateDayOfWeek = candidateDate.dayOfWeek.value
            if (candidateDayOfWeek in alarm.recurringDays) {
                val candidateDateTime = LocalDateTime.of(candidateDate, targetTime)
                if (candidateDateTime.isAfter(now)) {
                    return candidateDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                }
            }
        }

        // Fallback: next 7 days cycle
        val nextOccurrence = LocalDateTime.of(today.plusDays(7), targetTime)
        return nextOccurrence.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    /**
     * Calculates the effective snooze duration in minutes for the next snooze step.
     * Accounts for custom snooze decrement (escalating snooze).
     */
    fun calculateEffectiveSnoozeDuration(alarm: Alarm): Int {
        val baseDuration = max(1, alarm.snoozeDurationMinutes)
        val decrement = alarm.snoozeDecrementMinutes
        val count = alarm.currentSnoozeCount
        val reduced = baseDuration - (count * decrement)
        return max(1, reduced)
    }

    /**
     * Checks if this alarm can still be snoozed, given its maxSnoozeCount.
     */
    fun canSnooze(alarm: Alarm): Boolean {
        if (alarm.maxSnoozeCount == 0) return true // 0 means unlimited
        return alarm.currentSnoozeCount < alarm.maxSnoozeCount
    }

    /**
     * Calculates the remaining snooze count string: e.g., "Snooze 1 of 3 (2 remaining)"
     */
    fun getSnoozeRemainingText(alarm: Alarm): String {
        if (alarm.maxSnoozeCount == 0) {
            return "Snoozed ${alarm.currentSnoozeCount} times (Unlimited)"
        }
        val remaining = max(0, alarm.maxSnoozeCount - alarm.currentSnoozeCount)
        return "Snooze ${alarm.currentSnoozeCount} of ${alarm.maxSnoozeCount} ($remaining left)"
    }

    /**
     * Formats human-readable time remaining until next trigger.
     * e.g., "in 8 hours, 14 minutes", "in 4 minutes", "tomorrow at 7:00 AM"
     */
    fun formatTimeUntil(triggerMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val diffMillis = triggerMillis - nowMillis
        if (diffMillis <= 0) return "Right now"

        val totalMinutes = ChronoUnit.MINUTES.between(
            LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(nowMillis), ZoneId.systemDefault()),
            LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(triggerMillis), ZoneId.systemDefault())
        )

        val days = totalMinutes / (24 * 60)
        val hours = (totalMinutes % (24 * 60)) / 60
        val minutes = totalMinutes % 60

        return buildString {
            append("in ")
            if (days > 0) {
                append("$days day${if (days > 1) "s" else ""}, ")
            }
            if (hours > 0) {
                append("$hours hr${if (hours > 1) "s" else ""}")
                if (minutes > 0) append(" ")
            }
            if (minutes > 0 || (days == 0L && hours == 0L)) {
                append("${max(1, minutes)} min")
            }
        }
    }
}
