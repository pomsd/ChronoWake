package com.example.scheduler

import com.example.data.model.Alarm
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

object AlarmTriggerManager {
    private val _activeRingingAlarm = MutableStateFlow<Alarm?>(null)
    val activeRingingAlarm = _activeRingingAlarm.asStateFlow()

    private val _alarmEvents = MutableSharedFlow<AlarmEvent>(extraBufferCapacity = 10)
    val alarmEvents = _alarmEvents.asSharedFlow()

    fun setRingingAlarm(alarm: Alarm?) {
        _activeRingingAlarm.value = alarm
    }

    fun clearRingingAlarm() {
        _activeRingingAlarm.value = null
    }

    sealed class AlarmEvent {
        data class Triggered(val alarm: Alarm) : AlarmEvent()
        data class Snoozed(val alarm: Alarm, val untilMillis: Long) : AlarmEvent()
        data class Dismissed(val alarm: Alarm) : AlarmEvent()
    }
}
