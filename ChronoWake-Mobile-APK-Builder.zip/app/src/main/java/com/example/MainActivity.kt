package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.receiver.AlarmReceiver
import com.example.scheduler.AlarmTriggerManager
import com.example.ui.screens.alarm_edit.AlarmEditSheet
import com.example.ui.screens.alarm_list.AlarmListScreen
import com.example.ui.screens.ringing.AlarmRingingScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AlarmViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AlarmViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIntent(intent)

        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        val alarmId = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        val isRinging = intent.getBooleanExtra(AlarmReceiver.EXTRA_IS_RINGING, false)

        if (alarmId > 0 && isRinging) {
            // Find alarm and set ringing
            val currentAlarms = viewModel.alarms.value
            val matchingAlarm = currentAlarms.find { it.id == alarmId }
            if (matchingAlarm != null) {
                AlarmTriggerManager.setRingingAlarm(matchingAlarm)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: AlarmViewModel) {
    val alarms by viewModel.alarms.collectAsStateWithLifecycle()
    val nextAlarmPair by viewModel.nextUpcomingAlarm.collectAsStateWithLifecycle()
    val currentTimeMillis by viewModel.currentTimeSeconds.collectAsStateWithLifecycle()
    val activeRingingAlarm by viewModel.activeRingingAlarm.collectAsStateWithLifecycle()
    val editingAlarm by viewModel.editingAlarm.collectAsStateWithLifecycle()

    // Notification permission request for Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { _ -> }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        if (activeRingingAlarm != null) {
            // Priority Ringing Screen
            BackHandler {
                // If user presses physical back while ringing, snooze it
                activeRingingAlarm?.let { viewModel.snoozeAlarm(it) }
            }

            AlarmRingingScreen(
                alarm = activeRingingAlarm!!,
                onSnooze = { viewModel.snoozeAlarm(it) },
                onDismiss = { viewModel.dismissAlarm(it) }
            )
        } else {
            // Primary Alarms List Screen
            AlarmListScreen(
                alarms = alarms,
                nextAlarmPair = nextAlarmPair,
                currentTimeMillis = currentTimeMillis,
                onAddAlarm = { viewModel.openCreateAlarm() },
                onEditAlarm = { viewModel.openEditAlarm(it) },
                onToggleAlarm = { alarm, isEnabled -> viewModel.toggleAlarm(alarm, isEnabled) },
                onDeleteAlarm = { viewModel.deleteAlarm(it) },
                onTestAlarm = { viewModel.testAlarmRinging(it) },
                onDismissSnooze = { viewModel.dismissAlarm(it) },
                onAddQuickNap = { minutes -> viewModel.addQuickNap(minutes) }
            )

            // Edit / Add Bottom Sheet
            if (editingAlarm != null) {
                AlarmEditSheet(
                    alarm = editingAlarm!!,
                    onDismiss = { viewModel.closeEditAlarm() },
                    onSave = { updated -> viewModel.saveAlarm(updated) },
                    onDelete = { alarm -> viewModel.deleteAlarm(alarm) },
                    onPreviewTone = { tone -> viewModel.previewTone(tone) },
                    onStopPreview = { viewModel.stopSoundPreview() }
                )
            }
        }
    }
}
