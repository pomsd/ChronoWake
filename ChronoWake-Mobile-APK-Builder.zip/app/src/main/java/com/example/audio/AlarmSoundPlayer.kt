package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.example.data.model.SoundTone
import com.example.data.model.VibrationPattern
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

class AlarmSoundPlayer(private val context: Context) {

    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null
    private var vibrationJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    /**
     * Starts alarm playback (sound + vibration + optional volume crescendo)
     */
    fun start(
        tone: SoundTone,
        targetVolume: Float = 0.85f,
        gradualVolume: Boolean = true,
        vibrationPattern: VibrationPattern = VibrationPattern.HEARTBEAT
    ) {
        stop()

        startVibration(vibrationPattern)

        if (tone == SoundTone.SILENT) return

        playbackJob = scope.launch {
            try {
                val sampleRate = 44100
                val minBufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufferSize = (minBufferSize * 2).coerceAtLeast(sampleRate)

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack = track
                track.play()

                var currentVol = if (gradualVolume) 0.1f else targetVolume
                val volStep = (targetVolume - currentVol) / 20f

                val frequencies = getFrequenciesForTone(tone)
                var melodyIndex = 0

                while (isActive) {
                    if (gradualVolume && currentVol < targetVolume) {
                        currentVol = min(targetVolume, currentVol + volStep)
                    }
                    track.setVolume(currentVol)

                    val chord = frequencies[melodyIndex % frequencies.size]
                    val durationMs = chord.durationMs
                    val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
                    val pcmData = ShortArray(numSamples)

                    for (i in 0 until numSamples) {
                        val t = i.toDouble() / sampleRate
                        var sample = 0.0

                        for (freq in chord.notes) {
                            // Harmonic synthesis with gentle decay envelope
                            val envelope = (1.0 - (i.toDouble() / numSamples) * 0.4).coerceIn(0.1, 1.0)
                            sample += sin(2.0 * PI * freq * t) * envelope
                        }
                        sample /= chord.notes.size.coerceAtLeast(1)

                        // 16-bit PCM scale
                        pcmData[i] = (sample * Short.MAX_VALUE * 0.7).toInt().toShort()
                    }

                    track.write(pcmData, 0, pcmData.size)
                    melodyIndex++
                    delay(30)
                }
            } catch (e: Exception) {
                Log.w("ChronoWake", "Playback stopped or interrupted: ${e.message}")
            } finally {
                cleanUpAudio()
            }
        }
    }

    /**
     * Plays a short 2-second preview of a tone
     */
    fun previewTone(tone: SoundTone, volume: Float = 0.8f) {
        stop()
        if (tone == SoundTone.SILENT) return

        playbackJob = scope.launch {
            try {
                val sampleRate = 44100
                val minBufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufferSize * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack = track
                track.play()
                track.setVolume(volume)

                val notes = getFrequenciesForTone(tone).take(4)
                for (chord in notes) {
                    if (!isActive) break
                    val numSamples = (sampleRate * (chord.durationMs / 1000.0)).toInt()
                    val pcmData = ShortArray(numSamples)
                    for (i in 0 until numSamples) {
                        val t = i.toDouble() / sampleRate
                        var sample = 0.0
                        for (freq in chord.notes) {
                            val envelope = (1.0 - (i.toDouble() / numSamples) * 0.5).coerceIn(0.1, 1.0)
                            sample += sin(2.0 * PI * freq * t) * envelope
                        }
                        sample /= chord.notes.size.coerceAtLeast(1)
                        pcmData[i] = (sample * Short.MAX_VALUE * 0.6).toInt().toShort()
                    }
                    track.write(pcmData, 0, pcmData.size)
                }
            } catch (e: Exception) {
                Log.w("ChronoWake", "Tone preview error: ${e.message}")
            } finally {
                cleanUpAudio()
            }
        }
    }

    fun stop() {
        playbackJob?.cancel()
        playbackJob = null
        cleanUpAudio()
        stopVibration()
    }

    private fun cleanUpAudio() {
        try {
            audioTrack?.let {
                if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    it.stop()
                }
                it.release()
            }
        } catch (_: Exception) {}
        audioTrack = null
    }

    private fun startVibration(pattern: VibrationPattern) {
        if (pattern == VibrationPattern.OFF || vibrator == null) return

        vibrationJob = scope.launch {
            try {
                val timings = when (pattern) {
                    VibrationPattern.HEARTBEAT -> longArrayOf(0, 150, 100, 250, 600)
                    VibrationPattern.CONTINUOUS -> longArrayOf(0, 800, 200)
                    VibrationPattern.STACCATO -> longArrayOf(0, 80, 80, 80, 80, 400)
                    VibrationPattern.OFF -> longArrayOf()
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = VibrationEffect.createWaveform(timings, 0)
                    vibrator?.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(timings, 0)
                }
            } catch (e: Exception) {
                Log.w("ChronoWake", "Vibration failed: ${e.message}")
            }
        }
    }

    private fun stopVibration() {
        vibrationJob?.cancel()
        vibrationJob = null
        try {
            vibrator?.cancel()
        } catch (_: Exception) {}
    }

    private data class ChordSegment(val notes: List<Double>, val durationMs: Int)

    private fun getFrequenciesForTone(tone: SoundTone): List<ChordSegment> {
        return when (tone) {
            SoundTone.SUNRISE -> listOf(
                ChordSegment(listOf(261.63, 329.63), 350), // C4, E4
                ChordSegment(listOf(329.63, 392.00), 350), // E4, G4
                ChordSegment(listOf(392.00, 523.25), 450), // G4, C5
                ChordSegment(listOf(523.25, 659.25), 650), // C5, E5
                ChordSegment(listOf(392.00), 200)
            )
            SoundTone.HARP -> listOf(
                ChordSegment(listOf(349.23, 440.00, 523.25), 400), // F4, A4, C5
                ChordSegment(listOf(392.00, 493.88, 587.33), 400), // G4, B4, D5
                ChordSegment(listOf(440.00, 523.25, 659.25), 400), // A4, C5, E5
                ChordSegment(listOf(523.25, 659.25, 783.99), 600)  // C5, E5, G5
            )
            SoundTone.ENERGETIC -> listOf(
                ChordSegment(listOf(587.33), 160), // D5
                ChordSegment(listOf(659.25), 160), // E5
                ChordSegment(listOf(783.99), 220), // G5
                ChordSegment(listOf(880.00), 300), // A5
                ChordSegment(listOf(587.33, 880.00), 400)
            )
            SoundTone.CLASSIC_BELL -> listOf(
                ChordSegment(listOf(880.00, 1760.00), 200),
                ChordSegment(listOf(0.0), 100),
                ChordSegment(listOf(880.00, 1760.00), 200),
                ChordSegment(listOf(0.0), 300)
            )
            SoundTone.COSMIC -> listOf(
                ChordSegment(listOf(220.00, 440.00), 600),
                ChordSegment(listOf(277.18, 554.37), 600),
                ChordSegment(listOf(329.63, 659.25), 800)
            )
            SoundTone.SILENT -> emptyList()
        }
    }
}
