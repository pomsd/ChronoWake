package com.example.ui.screens.ringing

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Alarm
import com.example.data.model.ChallengeDifficulty
import com.example.data.model.WakeChallengeType
import com.example.scheduler.AlarmCalculationUtil
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.random.Random

@Composable
fun AlarmRingingScreen(
    alarm: Alarm,
    onSnooze: (Alarm) -> Unit,
    onDismiss: (Alarm) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    var currentTimeString by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val formatter = DateTimeFormatter.ofPattern("hh:mm:ss a")
        while (true) {
            currentTimeString = LocalTime.now().format(formatter)
            kotlinx.coroutines.delay(500)
        }
    }

    // Challenge state
    var challengePassed by remember {
        mutableStateOf(alarm.challengeType == WakeChallengeType.NONE)
    }

    // Math Challenge Generator
    var mathQuestion by remember { mutableStateOf("") }
    var mathAnswer by remember { mutableIntStateOf(0) }
    var enteredAnswer by remember { mutableStateOf("") }
    var mathError by remember { mutableStateOf(false) }

    // Tap Rhythm Challenge state
    var tapCount by remember { mutableIntStateOf(0) }
    val requiredTaps = 5

    LaunchedEffect(alarm.id) {
        if (alarm.challengeType == WakeChallengeType.MATH) {
            when (alarm.challengeDifficulty) {
                ChallengeDifficulty.EASY -> {
                    val a = Random.nextInt(5, 15)
                    val b = Random.nextInt(5, 15)
                    mathQuestion = "$a + $b"
                    mathAnswer = a + b
                }
                ChallengeDifficulty.MEDIUM -> {
                    val a = Random.nextInt(15, 50)
                    val b = Random.nextInt(15, 50)
                    mathQuestion = "$a + $b"
                    mathAnswer = a + b
                }
                ChallengeDifficulty.HARD -> {
                    val a = Random.nextInt(7, 18)
                    val b = Random.nextInt(6, 12)
                    mathQuestion = "$a × $b"
                    mathAnswer = a * b
                }
            }
        }
    }

    val canSnooze = remember(alarm) {
        AlarmCalculationUtil.canSnooze(alarm)
    }
    val effectiveSnoozeMinutes = remember(alarm) {
        AlarmCalculationUtil.calculateEffectiveSnoozeDuration(alarm)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E1B4B),
                        Color(0xFF31102A)
                    )
                )
            )
            .testTag("alarm_ringing_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top App Bar / Indicator
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 24.dp)
            ) {
                Surface(
                    color = Color(0x33F59E0B),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66F59E0B))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = Color(0xFFFBBF24),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ALARM RINGING",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFBBF24),
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = alarm.label,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Text(
                    text = currentTimeString,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFF94A3B8)
                )
            }

            // Center: Glowing Clock / Bell Animation & Challenges
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Pulsing sunrise ring
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(180.dp)
                        .scale(pulseScale)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color(0x66F59E0B),
                                        Color(0x22F43F5E),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF1E1B4B),
                        border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFFBBF24)),
                        modifier = Modifier.size(110.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Alarm,
                                contentDescription = null,
                                tint = Color(0xFFFBBF24),
                                modifier = Modifier.size(54.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Snooze Status Information
                if (alarm.currentSnoozeCount > 0) {
                    Surface(
                        color = Color(0x334F46E5),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = AlarmCalculationUtil.getSnoozeRemainingText(alarm),
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            color = Color(0xFFE0E7FF),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Interactive Challenge Card if not yet solved
                if (!challengePassed) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(0.95f)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            when (alarm.challengeType) {
                                WakeChallengeType.MATH -> {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Psychology,
                                            contentDescription = null,
                                            tint = Color(0xFFFBBF24)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Wake Challenge: Solve to Dismiss",
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = "$mathQuestion = ?",
                                        style = MaterialTheme.typography.headlineLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFBBF24)
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = if (enteredAnswer.isEmpty()) "Tap number buttons" else enteredAnswer,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = if (mathError) Color(0xFFF43F5E) else Color.White,
                                        fontWeight = FontWeight.Bold
                                    )

                                    if (mathError) {
                                        Text(
                                            text = "Incorrect, try again!",
                                            color = Color(0xFFF43F5E),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Compact keypad
                                    KeypadGrid(
                                        onDigit = { digit ->
                                            mathError = false
                                            if (enteredAnswer.length < 5) {
                                                enteredAnswer += digit
                                            }
                                        },
                                        onBackspace = {
                                            mathError = false
                                            if (enteredAnswer.isNotEmpty()) {
                                                enteredAnswer = enteredAnswer.dropLast(1)
                                            }
                                        },
                                        onSubmit = {
                                            if (enteredAnswer.toIntOrNull() == mathAnswer) {
                                                challengePassed = true
                                            } else {
                                                mathError = true
                                                enteredAnswer = ""
                                            }
                                        }
                                    )
                                }

                                WakeChallengeType.TAP_RHYTHM -> {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.TouchApp,
                                            contentDescription = null,
                                            tint = Color(0xFFFBBF24)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Tap Challenge: Tap $requiredTaps times",
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "$tapCount / $requiredTaps",
                                        style = MaterialTheme.typography.displaySmall,
                                        color = Color(0xFFFBBF24),
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = {
                                            tapCount++
                                            if (tapCount >= requiredTaps) {
                                                challengePassed = true
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFF59E0B)
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("TAP HERE!", fontWeight = FontWeight.Bold)
                                    }
                                }

                                WakeChallengeType.NONE -> {
                                    challengePassed = true
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Buttons: SNOOZE and DISMISS
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Snooze Button (Customization aware)
                if (canSnooze) {
                    OutlinedButton(
                        onClick = { onSnooze(alarm) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("snooze_alarm_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color(0x334F46E5),
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF6366F1))
                    ) {
                        Icon(imageVector = Icons.Default.Snooze, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Snooze (${effectiveSnoozeMinutes} min)",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                } else {
                    Surface(
                        color = Color(0x22F43F5E),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🚫 Max snooze limit reached (${alarm.maxSnoozeCount}/${alarm.maxSnoozeCount})",
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(12.dp),
                            color = Color(0xFFFDA4AF),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Dismiss Button
                Button(
                    onClick = {
                        if (challengePassed) {
                            onDismiss(alarm)
                        }
                    },
                    enabled = challengePassed,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .testTag("dismiss_alarm_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (challengePassed) Color(0xFF10B981) else Color(0xFF334155),
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = if (challengePassed) Icons.Default.Check else Icons.Default.Close,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (challengePassed) "Dismiss Alarm" else "Complete Challenge to Dismiss",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun KeypadGrid(
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    onSubmit: () -> Unit
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("⌫", "0", "OK")
    )

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (row in rows) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (item in row) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (item == "OK") Color(0xFF10B981)
                                else if (item == "⌫") Color(0xFF475569)
                                else Color(0xFF334155)
                            )
                            .clickable {
                                when (item) {
                                    "⌫" -> onBackspace()
                                    "OK" -> onSubmit()
                                    else -> onDigit(item)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = item,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }
    }
}
