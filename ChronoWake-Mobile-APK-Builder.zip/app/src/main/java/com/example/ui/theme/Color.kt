package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Sunrise Amber / Golden Glow
val AmberPrimary = Color(0xFFF59E0B)
val AmberSecondary = Color(0xFFD97706)
val AmberGlow = Color(0xFFFDE68A)

// Deep Midnight Dark Theme
val MidnightBackground = Color(0xFF0D111D)
val MidnightSurface = Color(0xFF161C2C)
val MidnightSurfaceVariant = Color(0xFF222B42)
val MidnightCardBorder = Color(0xFF2D374D)

// Accents
val AccentCoral = Color(0xFFF43F5E)
val AccentTeal = Color(0xFF10B981)
val AccentIndigo = Color(0xFF6366F1)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

// Light Theme Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightPrimary = Color(0xFFD97706)
val LightSecondary = Color(0xFF4F46E5)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
