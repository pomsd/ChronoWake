package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AlarmSoundPlayer
import com.example.data.local.AlarmDatabase
import com.example.data.model.Alarm
import com.example.data.model.SoundTone
import com.example.data.repository.AlarmRepository
import com.example.scheduler.AlarmCalculationUtil
import com.example.scheduler.AlarmScheduler
import com.example.scheduler.AlarmTriggerManager
import com.example.scheduler.AndroidAlarmScheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalTime

class AlarmViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AlarmDatabase.getDatabase(application)
    private val scheduler: AlarmScheduler = AndroidAlarmScheduler(application)
    private val repository = AlarmRepository(database.alarmDao(), scheduler)
    val soundPlayer = AlarmSoundPlayer(application)

    val alarms: StateFlow<List<Alarm>> = repository.allAlarms
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeRingingAlarm: StateFlow<Alarm?> = AlarmTriggerManager.activeRingingAlarm

    private val _editingAlarm = MutableStateFlow<Alarm?>(null)
    val editingAlarm: StateFlow<Alarm?> = _editingAlarm.asStateFlow()

    private val _currentTimeSeconds = MutableStateFlow(System.currentTimeMillis())
    val currentTimeSeconds: StateFlow<Long> = _currentTimeSeconds.asStateFlow()

    // Next alarm countdown derived state
    val nextUpcomingAlarm: StateFlow<Pair<Alarm, Long>?> = combine(
        alarms,
        _currentTimeSeconds
    ) { alarmList, _ ->
        val enabled = alarmList.filter { it.isEnabled }
        if (enabled.isEmpty()) {
            null
        } else {
            enabled.map { alarm ->
                val nextMillis = AlarmCalculationUtil.calculateNextTriggerMillis(alarm)
                alarm to nextMillis
            }.minByOrNull { it.second }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    init {
        // Ticking timer for clock display and countdown updates
        viewModelScope.launch {
            while (isActive) {
                _currentTimeSeconds.value = System.currentTimeMillis()
                delay(1000)
            }
        }

        // When ringing alarm changes, trigger or stop sound
        viewModelScope.launch {
            activeRingingAlarm.collect { alarm ->
                if (alarm != null) {
                    soundPlayer.start(
                        tone = alarm.soundTone,
                        targetVolume = alarm.volume,
                        gradualVolume = alarm.gradualVolume,
                        vibrationPattern = alarm.vibrationPattern
                    )
                } else {
                    soundPlayer.stop()
                }
            }
        }
    }

    fun openCreateAlarm() {
        val now = LocalTime.now().plusHours(1).withMinute(0)
        _editingAlarm.value = Alarm(
            hour = now.hour,
            minute = now.minute,
            label = "Morning Alarm",
            recurringDays = setOf(1, 2, 3, 4, 5), // Weekdays default
            snoozeDurationMinutes = 9,
            maxSnoozeCount = 3,
            snoozeDecrementMinutes = 0
        )
    }

    fun openEditAlarm(alarm: Alarm) {
        _editingAlarm.value = alarm
    }

    fun closeEditAlarm() {
        soundPlayer.stop()
        _editingAlarm.value = null
    }

    fun saveAlarm(alarm: Alarm) {
        viewModelScope.launch {
            repository.saveAlarm(alarm)
            closeEditAlarm()
        }
    }

    fun deleteAlarm(alarm: Alarm) {
        viewModelScope.launch {
            repository.deleteAlarm(alarm)
            if (_editingAlarm.value?.id == alarm.id) {
                closeEditAlarm()
            }
        }
    }

    fun toggleAlarm(alarm: Alarm, isEnabled: Boolean) {
        viewModelScope.launch {
            repository.toggleAlarm(alarm, isEnabled)
        }
    }

    fun snoozeAlarm(alarm: Alarm) {
        viewModelScope.launch {
            soundPlayer.stop()
            repository.snoozeAlarm(alarm)
            AlarmTriggerManager.clearRingingAlarm()
        }
    }

    fun dismissAlarm(alarm: Alarm) {
        viewModelScope.launch {
            soundPlayer.stop()
            repository.dismissAlarm(alarm)
            AlarmTriggerManager.clearRingingAlarm()
        }
    }

    fun addQuickNap(minutes: Int) {
        val target = LocalTime.now().plusMinutes(minutes.toLong())
        val napAlarm = Alarm(
            hour = target.hour,
            minute = target.minute,
            label = "Power Nap (${minutes}m)",
            recurringDays = emptySet(), // One-time
            snoozeDurationMinutes = 5,
            maxSnoozeCount = 2,
            snoozeDecrementMinutes = 1
        )
        viewModelScope.launch {
            repository.saveAlarm(napAlarm)
        }
    }

    fun testAlarmRinging(alarm: Alarm) {
        AlarmTriggerManager.setRingingAlarm(alarm)
    }

    fun previewTone(tone: SoundTone) {
        soundPlayer.previewTone(tone)
    }

    fun stopSoundPreview() {
        soundPlayer.stop()
    }

    override fun onCleared() {
        super.onCleared()
        soundPlayer.stop()
    }
}
