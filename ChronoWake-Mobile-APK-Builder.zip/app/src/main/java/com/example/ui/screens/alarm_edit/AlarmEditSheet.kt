package com.example.ui.screens.alarm_edit

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Alarm
import com.example.data.model.ChallengeDifficulty
import com.example.data.model.SoundTone
import com.example.data.model.VibrationPattern
import com.example.data.model.WakeChallengeType
import com.example.scheduler.AlarmCalculationUtil
import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AlarmEditSheet(
    alarm: Alarm,
    onDismiss: () -> Unit,
    onSave: (Alarm) -> Unit,
    onDelete: (Alarm) -> Unit,
    onPreviewTone: (SoundTone) -> Unit,
    onStopPreview: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var hour by remember { mutableIntStateOf(alarm.hour) }
    var minute by remember { mutableIntStateOf(alarm.minute) }
    var label by remember { mutableStateOf(alarm.label) }
    var recurringDays by remember { mutableStateOf(alarm.recurringDays) }

    // Snooze Customization
    var snoozeDurationMinutes by remember { mutableIntStateOf(alarm.snoozeDurationMinutes) }
    var maxSnoozeCount by remember { mutableIntStateOf(alarm.maxSnoozeCount) }
    var snoozeDecrementMinutes by remember { mutableIntStateOf(alarm.snoozeDecrementMinutes) }

    // Challenge
    var challengeType by remember { mutableStateOf(alarm.challengeType) }
    var challengeDifficulty by remember { mutableStateOf(alarm.challengeDifficulty) }

    // Sound & Vibration
    var soundTone by remember { mutableStateOf(alarm.soundTone) }
    var volume by remember { mutableFloatStateOf(alarm.volume) }
    var gradualVolume by remember { mutableStateOf(alarm.gradualVolume) }
    var vibrationPattern by remember { mutableStateOf(alarm.vibrationPattern) }
    var isPreviewingAudio by remember { mutableStateOf(false) }

    val currentDraftAlarm = remember(hour, minute, recurringDays, snoozeDurationMinutes, maxSnoozeCount, snoozeDecrementMinutes) {
        alarm.copy(
            hour = hour,
            minute = minute,
            label = label,
            recurringDays = recurringDays,
            snoozeDurationMinutes = snoozeDurationMinutes,
            maxSnoozeCount = maxSnoozeCount,
            snoozeDecrementMinutes = snoozeDecrementMinutes
        )
    }

    ModalBottomSheet(
        onDismissRequest = {
            onStopPreview()
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("alarm_edit_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 36.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (alarm.id == 0L) "New Alarm" else "Edit Alarm",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = {
                        onStopPreview()
                        onDismiss()
                    },
                    modifier = Modifier.testTag("close_sheet_button")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Time Selector Card
            TimeSelectorCard(
                hour = hour,
                minute = minute,
                onTimeChange = { newH, newM ->
                    hour = newH
                    minute = newM
                }
            )

            // Trigger countdown preview badge
            val nextMillis = AlarmCalculationUtil.calculateNextTriggerMillis(currentDraftAlarm)
            val countdown = AlarmCalculationUtil.formatTimeUntil(nextMillis)
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Alarm,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Alarm set to ring $countdown",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Label Input
            OutlinedTextField(
                value = label,
                onValueChange = { label = it },
                label = { Text("Alarm Label") },
                placeholder = { Text("e.g. Work, Morning Workout") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("alarm_label_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 1. RECURRING SCHEDULES SECTION
            SectionTitle(icon = Icons.Default.Repeat, title = "Recurring Schedule")
            RecurringSchedulePicker(
                selectedDays = recurringDays,
                onDaysChanged = { recurringDays = it }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // 2. SNOOZE CUSTOMIZATION OPTIONS (KEY PROMPT REQUIREMENT)
            SectionTitle(icon = Icons.Default.Snooze, title = "Snooze Customization")
            SnoozeCustomizationSection(
                durationMinutes = snoozeDurationMinutes,
                onDurationChange = { snoozeDurationMinutes = it },
                maxSnoozeCount = maxSnoozeCount,
                onMaxSnoozeChange = { maxSnoozeCount = it },
                decrementMinutes = snoozeDecrementMinutes,
                onDecrementChange = { snoozeDecrementMinutes = it }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // 3. WAKE-UP CHALLENGE
            SectionTitle(icon = Icons.Default.Psychology, title = "Wake-up Challenge")
            WakeChallengeSection(
                challengeType = challengeType,
                onTypeChanged = { challengeType = it },
                difficulty = challengeDifficulty,
                onDifficultyChanged = { challengeDifficulty = it }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // 4. SOUND & VIBRATION SECTION
            SectionTitle(icon = Icons.Default.GraphicEq, title = "Sound & Vibration")
            SoundVibrationSection(
                soundTone = soundTone,
                onToneChanged = {
                    soundTone = it
                    isPreviewingAudio = false
                    onStopPreview()
                },
                volume = volume,
                onVolumeChanged = { volume = it },
                gradualVolume = gradualVolume,
                onGradualVolumeChanged = { gradualVolume = it },
                vibrationPattern = vibrationPattern,
                onVibrationChanged = { vibrationPattern = it },
                isPreviewing = isPreviewingAudio,
                onTogglePreview = {
                    if (isPreviewingAudio) {
                        onStopPreview()
                        isPreviewingAudio = false
                    } else {
                        onPreviewTone(soundTone)
                        isPreviewingAudio = true
                    }
                }
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Bottom Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (alarm.id > 0L) {
                    OutlinedButton(
                        onClick = {
                            onStopPreview()
                            onDelete(alarm)
                        },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("delete_alarm_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Delete")
                    }
                }

                Button(
                    onClick = {
                        onStopPreview()
                        onSave(
                            alarm.copy(
                                hour = hour,
                                minute = minute,
                                label = label.ifBlank { "Alarm" },
                                isEnabled = true,
                                recurringDays = recurringDays,
                                snoozeDurationMinutes = snoozeDurationMinutes,
                                maxSnoozeCount = maxSnoozeCount,
                                snoozeDecrementMinutes = snoozeDecrementMinutes,
                                challengeType = challengeType,
                                challengeDifficulty = challengeDifficulty,
                                soundTone = soundTone,
                                volume = volume,
                                gradualVolume = gradualVolume,
                                vibrationPattern = vibrationPattern
                            )
                        )
                    },
                    modifier = Modifier
                        .weight(2f)
                        .testTag("save_alarm_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Save Alarm",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TimeSelectorCard(
    hour: Int,
    minute: Int,
    onTimeChange: (Int, Int) -> Unit
) {
    var isPm by remember(hour) { mutableStateOf(hour >= 12) }
    val displayHour = remember(hour) {
        if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Hour adjuster
                TimeNumberStepper(
                    value = displayHour,
                    range = 1..12,
                    formatString = "%02d",
                    onValueChange = { newDisp ->
                        val newH = if (isPm) {
                            if (newDisp == 12) 12 else newDisp + 12
                        } else {
                            if (newDisp == 12) 0 else newDisp
                        }
                        onTimeChange(newH, minute)
                    }
                )

                Text(
                    text = ":",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                // Minute adjuster
                TimeNumberStepper(
                    value = minute,
                    range = 0..59,
                    formatString = "%02d",
                    onValueChange = { newMin ->
                        onTimeChange(hour, newMin)
                    }
                )

                Spacer(modifier = Modifier.width(16.dp))

                // AM / PM Switcher Column
                Column(
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    AmPmToggle(
                        label = "AM",
                        isSelected = !isPm,
                        onClick = {
                            isPm = false
                            val h = if (hour >= 12) hour - 12 else hour
                            onTimeChange(h, minute)
                        }
                    )
                    AmPmToggle(
                        label = "PM",
                        isSelected = isPm,
                        onClick = {
                            isPm = true
                            val h = if (hour < 12) hour + 12 else hour
                            onTimeChange(h, minute)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TimeNumberStepper(
    value: Int,
    range: IntRange,
    formatString: String,
    onValueChange: (Int) -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        IconButton(
            onClick = {
                val next = if (value + 1 > range.last) range.first else value + 1
                onValueChange(next)
            },
            modifier = Modifier.size(36.dp)
        ) {
            Text("▲", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        }

        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.size(width = 80.dp, height = 70.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = String.format(Locale.getDefault(), formatString, value),
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        IconButton(
            onClick = {
                val prev = if (value - 1 < range.first) range.last else value - 1
                onValueChange(prev)
            },
            modifier = Modifier.size(36.dp)
        ) {
            Text("▼", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun AmPmToggle(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp)
            )
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            fontWeight = FontWeight.Bold,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RecurringSchedulePicker(
    selectedDays: Set<Int>,
    onDaysChanged: (Set<Int>) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Quick preset chips
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val isEveryday = selectedDays.size == 7
                val isWeekdays = selectedDays == setOf(1, 2, 3, 4, 5)
                val isWeekends = selectedDays == setOf(6, 7)
                val isOnce = selectedDays.isEmpty()

                FilterChip(
                    selected = isOnce,
                    onClick = { onDaysChanged(emptySet()) },
                    label = { Text("Once") }
                )
                FilterChip(
                    selected = isWeekdays,
                    onClick = { onDaysChanged(setOf(1, 2, 3, 4, 5)) },
                    label = { Text("Weekdays") }
                )
                FilterChip(
                    selected = isWeekends,
                    onClick = { onDaysChanged(setOf(6, 7)) },
                    label = { Text("Weekends") }
                )
                FilterChip(
                    selected = isEveryday,
                    onClick = { onDaysChanged((1..7).toSet()) },
                    label = { Text("Everyday") }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Day of week individual buttons (Mon to Sun)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val days = listOf(
                    1 to DayOfWeek.MONDAY,
                    2 to DayOfWeek.TUESDAY,
                    3 to DayOfWeek.WEDNESDAY,
                    4 to DayOfWeek.THURSDAY,
                    5 to DayOfWeek.FRIDAY,
                    6 to DayOfWeek.SATURDAY,
                    7 to DayOfWeek.SUNDAY
                )

                for ((dayNum, dayOfWeek) in days) {
                    val isSelected = dayNum in selectedDays
                    val shortName = dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault())

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surface
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                shape = CircleShape
                            )
                            .clickable {
                                val newSet = if (isSelected) {
                                    selectedDays - dayNum
                                } else {
                                    selectedDays + dayNum
                                }
                                onDaysChanged(newSet)
                            }
                    ) {
                        Text(
                            text = shortName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SnoozeCustomizationSection(
    durationMinutes: Int,
    onDurationChange: (Int) -> Unit,
    maxSnoozeCount: Int,
    onMaxSnoozeChange: (Int) -> Unit,
    decrementMinutes: Int,
    onDecrementChange: (Int) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // A. Snooze Duration
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Snooze Duration",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "$durationMinutes minutes",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Quick chips
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(3, 5, 9, 10, 15, 20, 30)
                    for (preset in presets) {
                        FilterChip(
                            selected = durationMinutes == preset,
                            onClick = { onDurationChange(preset) },
                            label = { Text("${preset}m") },
                            colors = FilterChipDefaults.filterChipColors()
                        )
                    }
                }

                Slider(
                    value = durationMinutes.toFloat(),
                    onValueChange = { onDurationChange(it.toInt()) },
                    valueRange = 1f..60f,
                    steps = 58,
                    colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary)
                )
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            // B. Max Snooze Limit
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Max Snooze Limit",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Prevents oversleeping",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (maxSnoozeCount == 0) "Unlimited" else "$maxSnoozeCount times",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val limits = listOf(0 to "Unlimited", 1 to "1 time", 2 to "2 times", 3 to "3 times", 5 to "5 times")
                    for ((cnt, text) in limits) {
                        FilterChip(
                            selected = maxSnoozeCount == cnt,
                            onClick = { onMaxSnoozeChange(cnt) },
                            label = { Text(text) }
                        )
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            // C. Escalating / Shrinking Snooze Option
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Escalating Snooze",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (decrementMinutes > 0)
                                "Reduces by ${decrementMinutes}m each snooze (e.g., ${durationMinutes}m → ${kotlin.math.max(1, durationMinutes - decrementMinutes)}m)"
                            else "Keep duration constant each snooze",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = decrementMinutes > 0,
                        onCheckedChange = { isChecked ->
                            onDecrementChange(if (isChecked) 2 else 0)
                        }
                    )
                }

                AnimatedVisibility(visible = decrementMinutes > 0) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 2, 3, 5).forEach { dec ->
                            FilterChip(
                                selected = decrementMinutes == dec,
                                onClick = { onDecrementChange(dec) },
                                label = { Text("-${dec}m / snooze") }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WakeChallengeSection(
    challengeType: WakeChallengeType,
    onTypeChanged: (WakeChallengeType) -> Unit,
    difficulty: ChallengeDifficulty,
    onDifficultyChanged: (ChallengeDifficulty) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WakeChallengeType.values().forEach { type ->
                    FilterChip(
                        selected = challengeType == type,
                        onClick = { onTypeChanged(type) },
                        label = { Text(type.title) }
                    )
                }
            }

            AnimatedVisibility(visible = challengeType == WakeChallengeType.MATH) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = "Math Difficulty Level",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChallengeDifficulty.values().forEach { diff ->
                            FilterChip(
                                selected = difficulty == diff,
                                onClick = { onDifficultyChanged(diff) },
                                label = { Text(diff.name.lowercase().capitalize(Locale.ROOT)) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SoundVibrationSection(
    soundTone: SoundTone,
    onToneChanged: (SoundTone) -> Unit,
    volume: Float,
    onVolumeChanged: (Float) -> Unit,
    gradualVolume: Boolean,
    onGradualVolumeChanged: (Boolean) -> Unit,
    vibrationPattern: VibrationPattern,
    onVibrationChanged: (VibrationPattern) -> Unit,
    isPreviewing: Boolean,
    onTogglePreview: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Sound Melody Selector
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Alarm Melody",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedButton(
                        onClick = onTogglePreview,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isPreviewing) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isPreviewing) "Stop" else "Preview")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                SoundTone.values().forEach { tone ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onToneChanged(tone) }
                            .padding(vertical = 6.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(
                                    if (soundTone == tone) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                )
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = tone.title,
                                fontWeight = if (soundTone == tone) FontWeight.Bold else FontWeight.Normal,
                                color = if (soundTone == tone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = tone.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            // Volume & Crescendo
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Volume", fontWeight = FontWeight.SemiBold)
                    }
                    Text("${(volume * 100).toInt()}%", fontWeight = FontWeight.Bold)
                }

                Slider(
                    value = volume,
                    onValueChange = onVolumeChanged,
                    valueRange = 0.1f..1.0f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Gentle Wake (Crescendo)", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Gradually increases volume over 60 seconds",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = gradualVolume,
                        onCheckedChange = onGradualVolumeChanged
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            // Vibration Pattern
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Vibration Pattern", fontWeight = FontWeight.SemiBold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    VibrationPattern.values().forEach { pat ->
                        FilterChip(
                            selected = vibrationPattern == pat,
                            onClick = { onVibrationChanged(pat) },
                            label = { Text(pat.title) }
                        )
                    }
                }
            }
        }
    }
}
