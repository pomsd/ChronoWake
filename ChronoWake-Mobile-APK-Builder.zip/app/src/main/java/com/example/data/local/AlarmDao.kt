package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour ASC, minute ASC")
    fun getAllAlarms(): Flow<List<AlarmEntity>>

    @Query("SELECT * FROM alarms WHERE isEnabled = 1 ORDER BY hour ASC, minute ASC")
    fun getEnabledAlarms(): Flow<List<AlarmEntity>>

    @Query("SELECT * FROM alarms WHERE id = :id LIMIT 1")
    suspend fun getAlarmById(id: Long): AlarmEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(alarm: AlarmEntity): Long

    @Update
    suspend fun updateAlarm(alarm: AlarmEntity)

    @Delete
    suspend fun deleteAlarm(alarm: AlarmEntity)

    @Query("DELETE FROM alarms WHERE id = :id")
    suspend fun deleteAlarmById(id: Long)

    @Query("UPDATE alarms SET isEnabled = :isEnabled, currentSnoozeCount = 0, snoozedUntilMillis = 0 WHERE id = :id")
    suspend fun toggleAlarmState(id: Long, isEnabled: Boolean)

    @Query("UPDATE alarms SET currentSnoozeCount = :snoozeCount, snoozedUntilMillis = :snoozedUntil WHERE id = :id")
    suspend fun updateSnoozeState(id: Long, snoozeCount: Int, snoozedUntil: Long)

    @Query("UPDATE alarms SET currentSnoozeCount = 0, snoozedUntilMillis = 0 WHERE id = :id")
    suspend fun clearSnooze(id: Long)
}
