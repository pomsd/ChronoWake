package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [AlarmEntity::class], version = 1, exportSchema = false)
abstract class AlarmDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao

    companion object {
        @Volatile
        private var INSTANCE: AlarmDatabase? = null

        fun getDatabase(context: Context): AlarmDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AlarmDatabase::class.java,
                    "chronowake_alarms.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Prepopulate default alarms so user has immediate helpful examples
                        CoroutineScope(Dispatchers.IO).launch {
                            getDatabase(context).alarmDao().let { dao ->
                                dao.insertAlarm(
                                    AlarmEntity(
                                        hour = 7,
                                        minute = 0,
                                        label = "Morning Rise",
                                        isEnabled = true,
                                        daysOfWeek = "1,2,3,4,5", // Weekdays
                                        snoozeDurationMinutes = 9,
                                        maxSnoozeCount = 3,
                                        snoozeDecrementMinutes = 1, // Decreases by 1m each snooze
                                        challengeType = "NONE",
                                        soundTone = "SUNRISE",
                                        volume = 0.85f,
                                        gradualVolume = true,
                                        vibrationPattern = "HEARTBEAT"
                                    )
                                )
                                dao.insertAlarm(
                                    AlarmEntity(
                                        hour = 8,
                                        minute = 30,
                                        label = "Weekend Bliss",
                                        isEnabled = false,
                                        daysOfWeek = "6,7", // Sat, Sun
                                        snoozeDurationMinutes = 15,
                                        maxSnoozeCount = 5,
                                        snoozeDecrementMinutes = 0,
                                        challengeType = "NONE",
                                        soundTone = "HARP",
                                        volume = 0.75f,
                                        gradualVolume = true,
                                        vibrationPattern = "CONTINUOUS"
                                    )
                                )
                                dao.insertAlarm(
                                    AlarmEntity(
                                        hour = 6,
                                        minute = 15,
                                        label = "Power Workout",
                                        isEnabled = false,
                                        daysOfWeek = "1,3,5", // Mon, Wed, Fri
                                        snoozeDurationMinutes = 5,
                                        maxSnoozeCount = 1, // Strict limit!
                                        snoozeDecrementMinutes = 0,
                                        challengeType = "MATH",
                                        challengeDifficulty = "MEDIUM",
                                        soundTone = "ENERGETIC",
                                        volume = 1.0f,
                                        gradualVolume = false,
                                        vibrationPattern = "STACCATO"
                                    )
                                )
                            }
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
