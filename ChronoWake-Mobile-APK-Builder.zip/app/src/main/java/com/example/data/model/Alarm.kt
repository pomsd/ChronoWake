package com.example.data.model

import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale

enum class RecurringPreset(val label: String) {
    ONCE("Once"),
    EVERYDAY("Everyday"),
    WEEKDAYS("Weekdays (Mon-Fri)"),
    WEEKENDS("Weekends (Sat-Sun)"),
    CUSTOM("Custom")
}

enum class SoundTone(val title: String, val description: String) {
    SUNRISE("Sunrise Glow", "Calm ascending chime melody"),
    HARP("Celestial Harp", "Gentle relaxing harmonic harp"),
    ENERGETIC("Morning Spark", "Upbeat rhythmic wake-up tones"),
    CLASSIC_BELL("Classic Clock", "Traditional mechanical bell pulse"),
    COSMIC("Cosmic Waves", "Deep ambient melodic synth pulses"),
    SILENT("Vibrate Only", "No audio playback")
}

enum class VibrationPattern(val title: String) {
    HEARTBEAT("Heartbeat"),
    CONTINUOUS("Continuous"),
    STACCATO("Staccato (Rapid)"),
    OFF("Off")
}

enum class WakeChallengeType(val title: String, val description: String) {
    NONE("Simple Button", "Regular tap or swipe to dismiss"),
    MATH("Math Equation", "Solve arithmetic to dismiss alarm"),
    TAP_RHYTHM("Tap Speed Challenge", "Tap 5 times in rapid succession")
}

enum class ChallengeDifficulty(val title: String) {
    EASY("Easy (e.g., 7 + 8)"),
    MEDIUM("Medium (e.g., 23 + 48)"),
    HARD("Hard (e.g., 14 × 7)")
}

data class DaySelection(
    val day: DayOfWeek,
    val isSelected: Boolean
) {
    val shortName: String
        get() = day.getDisplayName(TextStyle.SHORT, Locale.getDefault())
}

data class Alarm(
    val id: Long = 0,
    val hour: Int = 7,
    val minute: Int = 0,
    val label: String = "Alarm",
    val isEnabled: Boolean = true,
    // Days 1..7 (Monday = 1, Sunday = 7)
    val recurringDays: Set<Int> = setOf(1, 2, 3, 4, 5), // Weekdays default
    
    // Snooze Customization Options
    val snoozeDurationMinutes: Int = 9,
    val maxSnoozeCount: Int = 3, // 0 for unlimited, 1..10
    val snoozeDecrementMinutes: Int = 0, // e.g. 0 = fixed; 2 = reduces by 2 min each snooze
    val currentSnoozeCount: Int = 0,
    val snoozedUntilMillis: Long = 0L,
    
    // Wake-up Challenge
    val challengeType: WakeChallengeType = WakeChallengeType.NONE,
    val challengeDifficulty: ChallengeDifficulty = ChallengeDifficulty.EASY,
    
    // Sound & Vibration
    val soundTone: SoundTone = SoundTone.SUNRISE,
    val volume: Float = 0.85f,
    val gradualVolume: Boolean = true, // Crescendo gentle volume ramp
    val vibrationPattern: VibrationPattern = VibrationPattern.HEARTBEAT,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isSnoozed: Boolean
        get() = snoozedUntilMillis > System.currentTimeMillis()

    val formattedTime: String
        get() {
            val h = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
            return String.format(Locale.getDefault(), "%d:%02d", h, minute)
        }

    val amPm: String
        get() = if (hour < 12) "AM" else "PM"

    val formatted24Hour: String
        get() = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)

    val recurringSummary: String
        get() {
            if (recurringDays.isEmpty()) return "Once"
            if (recurringDays.size == 7) return "Every day"
            val weekdays = setOf(1, 2, 3, 4, 5)
            val weekends = setOf(6, 7)
            if (recurringDays == weekdays) return "Weekdays (Mon - Fri)"
            if (recurringDays == weekends) return "Weekends (Sat - Sun)"

            val dayNames = listOf(
                1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu",
                5 to "Fri", 6 to "Sat", 7 to "Sun"
            )
            return dayNames
                .filter { it.first in recurringDays }
                .joinToString(", ") { it.second }
        }

    val snoozeSummary: String
        get() {
            val dec = if (snoozeDecrementMinutes > 0) " (-${snoozeDecrementMinutes}m/snooze)" else ""
            val count = if (maxSnoozeCount == 0) "Unlimited" else "Max $maxSnoozeCount×"
            return "${snoozeDurationMinutes}m$dec • $count"
        }
}
