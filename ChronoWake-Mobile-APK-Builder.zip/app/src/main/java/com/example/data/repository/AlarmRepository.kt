package com.example.data.repository

import com.example.data.local.AlarmDao
import com.example.data.local.AlarmEntity
import com.example.data.model.Alarm
import com.example.scheduler.AlarmCalculationUtil
import com.example.scheduler.AlarmScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AlarmRepository(
    private val alarmDao: AlarmDao,
    private val scheduler: AlarmScheduler
) {
    val allAlarms: Flow<List<Alarm>> = alarmDao.getAllAlarms().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun getAlarmById(id: Long): Alarm? {
        return alarmDao.getAlarmById(id)?.toDomain()
    }

    suspend fun saveAlarm(alarm: Alarm): Long {
        val entity = AlarmEntity.fromDomain(alarm)
        val id = if (alarm.id == 0L) {
            alarmDao.insertAlarm(entity)
        } else {
            alarmDao.updateAlarm(entity)
            alarm.id
        }

        val updatedAlarm = alarm.copy(id = id)
        if (updatedAlarm.isEnabled) {
            scheduler.scheduleAlarm(updatedAlarm)
        } else {
            scheduler.cancelAlarm(updatedAlarm)
        }
        return id
    }

    suspend fun toggleAlarm(alarm: Alarm, enabled: Boolean) {
        alarmDao.toggleAlarmState(alarm.id, enabled)
        val updated = alarm.copy(isEnabled = enabled, currentSnoozeCount = 0, snoozedUntilMillis = 0)
        if (enabled) {
            scheduler.scheduleAlarm(updated)
        } else {
            scheduler.cancelAlarm(updated)
        }
    }

    suspend fun snoozeAlarm(alarm: Alarm): Long {
        val durationMinutes = AlarmCalculationUtil.calculateEffectiveSnoozeDuration(alarm)
        val snoozeUntilMillis = System.currentTimeMillis() + (durationMinutes * 60_000L)
        val nextSnoozeCount = alarm.currentSnoozeCount + 1

        alarmDao.updateSnoozeState(alarm.id, nextSnoozeCount, snoozeUntilMillis)
        val snoozedAlarm = alarm.copy(
            currentSnoozeCount = nextSnoozeCount,
            snoozedUntilMillis = snoozeUntilMillis
        )
        scheduler.scheduleSnooze(snoozedAlarm, snoozeUntilMillis)
        return snoozeUntilMillis
    }

    suspend fun dismissAlarm(alarm: Alarm) {
        alarmDao.clearSnooze(alarm.id)
        if (alarm.recurringDays.isEmpty()) {
            // One-time alarm turns off after firing
            alarmDao.toggleAlarmState(alarm.id, false)
            scheduler.cancelAlarm(alarm)
        } else {
            // Recurring alarm prepares for next cycle
            val resetAlarm = alarm.copy(currentSnoozeCount = 0, snoozedUntilMillis = 0L)
            scheduler.scheduleAlarm(resetAlarm)
        }
    }

    suspend fun deleteAlarm(alarm: Alarm) {
        scheduler.cancelAlarm(alarm)
        alarmDao.deleteAlarmById(alarm.id)
    }

    suspend fun rescheduleAllActiveAlarms() {
        val alarms = alarmDao.getAllAlarms()
        // Note: Used on boot or app start
    }
}
