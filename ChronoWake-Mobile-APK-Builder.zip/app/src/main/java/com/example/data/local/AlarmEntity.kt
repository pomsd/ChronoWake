package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.Alarm
import com.example.data.model.ChallengeDifficulty
import com.example.data.model.SoundTone
import com.example.data.model.VibrationPattern
import com.example.data.model.WakeChallengeType

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val hour: Int,
    val minute: Int,
    val label: String,
    val isEnabled: Boolean = true,
    val daysOfWeek: String = "1,2,3,4,5",
    val snoozeDurationMinutes: Int = 9,
    val maxSnoozeCount: Int = 3,
    val snoozeDecrementMinutes: Int = 0,
    val currentSnoozeCount: Int = 0,
    val snoozedUntilMillis: Long = 0L,
    val challengeType: String = "NONE",
    val challengeDifficulty: String = "EASY",
    val soundTone: String = "SUNRISE",
    val volume: Float = 0.85f,
    val gradualVolume: Boolean = true,
    val vibrationPattern: String = "HEARTBEAT",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): Alarm {
        val days = if (daysOfWeek.isBlank()) {
            emptySet()
        } else {
            daysOfWeek.split(",")
                .mapNotNull { it.trim().toIntOrNull() }
                .toSet()
        }

        return Alarm(
            id = id,
            hour = hour,
            minute = minute,
            label = label,
            isEnabled = isEnabled,
            recurringDays = days,
            snoozeDurationMinutes = snoozeDurationMinutes,
            maxSnoozeCount = maxSnoozeCount,
            snoozeDecrementMinutes = snoozeDecrementMinutes,
            currentSnoozeCount = currentSnoozeCount,
            snoozedUntilMillis = snoozedUntilMillis,
            challengeType = try {
                WakeChallengeType.valueOf(challengeType)
            } catch (_: Exception) {
                WakeChallengeType.NONE
            },
            challengeDifficulty = try {
                ChallengeDifficulty.valueOf(challengeDifficulty)
            } catch (_: Exception) {
                ChallengeDifficulty.EASY
            },
            soundTone = try {
                SoundTone.valueOf(soundTone)
            } catch (_: Exception) {
                SoundTone.SUNRISE
            },
            volume = volume,
            gradualVolume = gradualVolume,
            vibrationPattern = try {
                VibrationPattern.valueOf(vibrationPattern)
            } catch (_: Exception) {
                VibrationPattern.HEARTBEAT
            },
            createdAt = createdAt
        )
    }

    companion object {
        fun fromDomain(alarm: Alarm): AlarmEntity {
            val days = alarm.recurringDays.sorted().joinToString(",")
            return AlarmEntity(
                id = alarm.id,
                hour = alarm.hour,
                minute = alarm.minute,
                label = alarm.label,
                isEnabled = alarm.isEnabled,
                daysOfWeek = days,
                snoozeDurationMinutes = alarm.snoozeDurationMinutes,
                maxSnoozeCount = alarm.maxSnoozeCount,
                snoozeDecrementMinutes = alarm.snoozeDecrementMinutes,
                currentSnoozeCount = alarm.currentSnoozeCount,
                snoozedUntilMillis = alarm.snoozedUntilMillis,
                challengeType = alarm.challengeType.name,
                challengeDifficulty = alarm.challengeDifficulty.name,
                soundTone = alarm.soundTone.name,
                volume = alarm.volume,
                gradualVolume = alarm.gradualVolume,
                vibrationPattern = alarm.vibrationPattern.name,
                createdAt = alarm.createdAt
            )
        }
    }
}
