package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.AlarmDatabase
import com.example.data.repository.AlarmRepository
import com.example.scheduler.AndroidAlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AlarmDatabase.getDatabase(context)
                    val scheduler = AndroidAlarmScheduler(context)
                    val repository = AlarmRepository(db.alarmDao(), scheduler)
                    val activeAlarms = repository.allAlarms.first().filter { it.isEnabled }
                    for (alarm in activeAlarms) {
                        scheduler.scheduleAlarm(alarm)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
