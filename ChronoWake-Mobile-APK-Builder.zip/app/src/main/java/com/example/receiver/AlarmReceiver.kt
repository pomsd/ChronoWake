package com.example.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AlarmDatabase
import com.example.data.repository.AlarmRepository
import com.example.scheduler.AlarmCalculationUtil
import com.example.scheduler.AlarmScheduler
import com.example.scheduler.AlarmTriggerManager
import com.example.scheduler.AndroidAlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        val action = intent.action ?: ACTION_ALARM_TRIGGER

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AlarmDatabase.getDatabase(context)
                val scheduler = AndroidAlarmScheduler(context)
                val repository = AlarmRepository(db.alarmDao(), scheduler)

                val alarm = if (alarmId > 0) repository.getAlarmById(alarmId) else null

                when (action) {
                    ACTION_ALARM_TRIGGER -> {
                        if (alarm != null && alarm.isEnabled) {
                            AlarmTriggerManager.setRingingAlarm(alarm)
                            showAlarmNotification(context, alarm)

                            // Try to launch MainActivity into ringing mode
                            val activityIntent = Intent(context, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                                putExtra(EXTRA_ALARM_ID, alarm.id)
                                putExtra(EXTRA_IS_RINGING, true)
                            }
                            try {
                                context.startActivity(activityIntent)
                            } catch (_: Exception) {}
                        }
                    }

                    ACTION_ALARM_SNOOZE -> {
                        if (alarm != null) {
                            repository.snoozeAlarm(alarm)
                            AlarmTriggerManager.clearRingingAlarm()
                            cancelNotification(context, alarm.id.toInt())
                        }
                    }

                    ACTION_ALARM_DISMISS -> {
                        if (alarm != null) {
                            repository.dismissAlarm(alarm)
                            AlarmTriggerManager.clearRingingAlarm()
                            cancelNotification(context, alarm.id.toInt())
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showAlarmNotification(context: Context, alarm: com.example.data.model.Alarm) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel(notificationManager)

        // Full screen / Tap intent
        val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ALARM_ID, alarm.id)
            putExtra(EXTRA_IS_RINGING, true)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            alarm.id.toInt(),
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Snooze intent
        val snoozeIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM_SNOOZE
            putExtra(EXTRA_ALARM_ID, alarm.id)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (alarm.id * 10 + 1).toInt(),
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Dismiss intent
        val dismissIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM_DISMISS
            putExtra(EXTRA_ALARM_ID, alarm.id)
        }
        val dismissPendingIntent = PendingIntent.getBroadcast(
            context,
            (alarm.id * 10 + 2).toInt(),
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val effectiveSnooze = AlarmCalculationUtil.calculateEffectiveSnoozeDuration(alarm)
        val canSnooze = AlarmCalculationUtil.canSnooze(alarm)

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ ${alarm.label}")
            .setContentText("Alarm ringing for ${alarm.formattedTime} ${alarm.amPm}")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(false)
            .setOngoing(true)
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)

        if (canSnooze) {
            builder.addAction(
                android.R.drawable.ic_popup_sync,
                "Snooze (${effectiveSnooze}m)",
                snoozePendingIntent
            )
        }

        builder.addAction(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Dismiss",
            dismissPendingIntent
        )

        notificationManager.notify(alarm.id.toInt(), builder.build())
    }

    private fun cancelNotification(context: Context, notificationId: Int) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(notificationId)
    }

    companion object {
        const val CHANNEL_ID = "chronowake_alarms_channel"
        const val ACTION_ALARM_TRIGGER = "com.example.ACTION_ALARM_TRIGGER"
        const val ACTION_ALARM_SNOOZE = "com.example.ACTION_ALARM_SNOOZE"
        const val ACTION_ALARM_DISMISS = "com.example.ACTION_ALARM_DISMISS"

        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_IS_SNOOZE_RING = "extra_is_snooze_ring"
        const val EXTRA_IS_RINGING = "extra_is_ringing"

        fun createNotificationChannel(notificationManager: NotificationManager) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "ChronoWake Alarms",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "High-priority notifications for ringing alarms"
                    enableVibration(true)
                    setShowBadge(true)
                    setBypassDnd(true)
                }
                notificationManager.createNotificationChannel(channel)
            }
        }
    }
}
