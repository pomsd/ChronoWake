package com.example

import com.example.data.model.Alarm
import com.example.scheduler.AlarmCalculationUtil
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime

class ExampleUnitTest {
    @Test
    fun testSnoozeEffectiveDurationFixed() {
        val alarm = Alarm(
            snoozeDurationMinutes = 10,
            snoozeDecrementMinutes = 0,
            currentSnoozeCount = 2
        )
        val duration = AlarmCalculationUtil.calculateEffectiveSnoozeDuration(alarm)
        assertEquals(10, duration)
    }

    @Test
    fun testEscalatingSnoozeReduction() {
        val alarm = Alarm(
            snoozeDurationMinutes = 10,
            snoozeDecrementMinutes = 2,
            currentSnoozeCount = 2
        )
        // 10 - (2 * 2) = 6 min
        val duration = AlarmCalculationUtil.calculateEffectiveSnoozeDuration(alarm)
        assertEquals(6, duration)
    }

    @Test
    fun testMaxSnoozeLimitCheck() {
        val alarmLimited = Alarm(
            maxSnoozeCount = 3,
            currentSnoozeCount = 3
        )
        assertFalse(AlarmCalculationUtil.canSnooze(alarmLimited))

        val alarmAllowed = Alarm(
            maxSnoozeCount = 3,
            currentSnoozeCount = 2
        )
        assertTrue(AlarmCalculationUtil.canSnooze(alarmAllowed))

        val alarmUnlimited = Alarm(
            maxSnoozeCount = 0,
            currentSnoozeCount = 10
        )
        assertTrue(AlarmCalculationUtil.canSnooze(alarmUnlimited))
    }

    @Test
    fun testRecurringDaysNextTrigger() {
        // Monday = 1
        val now = LocalDateTime.of(2026, 10, 5, 8, 0) // Oct 5, 2026 is Monday
        val alarm = Alarm(
            hour = 9,
            minute = 0,
            recurringDays = setOf(1) // Monday only
        )
        val nextMillis = AlarmCalculationUtil.calculateNextTriggerMillis(alarm, now)
        assertTrue(nextMillis > 0)
    }
}
